// Ejercicio1.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
#include <iostream>
using namespace std;

//Atributos enemigo
int enemyHP = 200;
int enemyDMG = 10;
string enemyName = "Jorge";
bool enemyIsAlive = true;

//ENEMIGO 2
int enemyHP2 = 200;
int enemyDMG2 = 10;
string enemyName2 = "Aquarius";
bool enemyIsAlive2 = true;

//Atributos del personaje

int heroHP = 200;
int heroDamage;
string heroname;
bool heroIsAlive = true;

//OTROS
int respuesta;

//PODERES
int ataques;
int Espada = 30;
int Magia = 40;
int Punetazo = 25;
int magiaintentos = 5;
int respuesta2;




void inicio() {
    cout << " El enemigo " << enemyName << " ha aparecido\n ";
    cout << "Como se llama el heroe\n";
    cin >> heroname;
    cout << "El nombre del heroe es:  " << heroname << "\n";
}

int eleccion() {
    if(enemyIsAlive && enemyIsAlive2){
        cout << "A que enemigo quieres atacar (1)Jorge o (2)Aquarius: " << "\n";
    }else if (!enemyIsAlive) {
        cout << "Atacar a (2)Aquarius\n";
    }
    else if (!enemyIsAlive2) {
        cout << "Atacar a (1)Jorge\n";
    }
    cin >> respuesta;
    return respuesta;
}

void Damageenemy(int& enemyHP, int heroDamage, string& enemyName, int HeroHP, int& enemyDMG) {
    enemyHP = enemyHP - heroDamage;
    if (enemyHP <= 0) {
        cout << " Se tropezo " << enemyName << "\n";
        enemyIsAlive = false;

    }
    if (enemyHP == 0) {
        cout << "el enemigo ha muerto\n";
    }
    else {
        cout << " El enemigo " << enemyName << " tiene " << enemyHP << " puntos de vida\n ";
        heroHP = heroHP - enemyDMG - rand() % 15;
        fheroIsAlive();
        cout << " El enemigo " << enemyName << " te ha atacado y te quedan " << heroHP << "HP" "\n";


    }
}


void enemigos() {

    // ENEMIGO 1
    if (respuesta == 1) {
        Damageenemy(enemyHP, heroDamage,enemyName, HeroHP, enemyDMG)

    }


    // ENEMIGO 2
    if (respuesta == 2) {
        Damageenemy(enemyHP2, heroDamage, enemyName2, HeroHP, enemyDMG2)

    }
    else if (respuesta != 1 && respuesta != 2) {
        cout << " Este enemigo no existe \n";
    }
}

void seleccion() {
    cout << "Con que quieres atacar (1) Espada, (2) Magia(te quedan " << magiaintentos << " ), (3)Puñetazo\n";
    cin >> ataques;

    // SELECCIÓN DE ATAQUES

    switch (ataques) {

    case 1:
        heroDamage = Espada;
        break;
    case 2:
        if (magiaintentos == 0) {
            cout << "No puedes utilizar el ataque otra vez";
            cout << "Escoge un ataque: 1.Espada 3.Puñetazo";
            magiaintentos = 0;
            if (respuesta == 1) {
                heroDamage = Espada;
            }
            else if (respuesta2 == 3) {
                heroDamage = Punetazo;
            }

        }
        else {
            heroDamage = Magia;
            magiaintentos = magiaintentos - 1;
        }
        break;
    case 3:
        heroDamage = Punetazo;
        break;
    }
}

bool fheroIsAlive() {
    if (heroHP <= 0) {
        cout << "HAS SIDO DERROTADO";
        heroHP = 0;
        heroIsAlive = false;
        return false;
    }else {
        return true;
    }
}



int main() {
    inicio();
    srand(time(NULL));
    while ((enemyIsAlive || enemyIsAlive2) && (heroIsAlive)) {
        enemigos();
        eleccion();
        seleccion();
        fheroIsAlive();
    }
}

